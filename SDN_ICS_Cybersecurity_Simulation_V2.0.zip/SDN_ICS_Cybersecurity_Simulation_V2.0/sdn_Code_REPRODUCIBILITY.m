
%% =========================================================================
% SDN-ICS REPRODUCIBILITY RUNNER
% Dissertation: Development of a Software Defined Network Based
% Cybersecurity Framework for Industrial Control Systems
%
% Authors: Mupatiwa Zulu and Lukumba Phiri
% University of Zambia
%
% This runner executes the authoritative three-mode simulation
% maintained in sdn_Code.m.
%
% Modes:
% 1. Baseline (no security app)
% 2. Static ACL
% 3. SDN-Sec
%
% Requirements: MATLAB R2020a or later; Base MATLAB only.
%% =========================================================================

clc;
close all;

% Locate this runner's directory
projectDir = fileparts(mfilename('fullpath'));

if isempty(projectDir)
    projectDir = pwd;
end

% Set the working directory
cd(projectDir);

% Confirm the authoritative simulation exists
if ~isfile(fullfile(projectDir,'sdn_Code.m'))
    error('ERROR: sdn_Code.m was not found in the project directory.');
end

fprintf('\n========================================\n');
fprintf('SDN-ICS REPRODUCIBILITY RUN\n');
fprintf('========================================\n');

fprintf('Executing the authoritative simulation: sdn_Code.m\n\n');

% Execute the complete simulation
run(fullfile(projectDir,'sdn_Code.m'));
