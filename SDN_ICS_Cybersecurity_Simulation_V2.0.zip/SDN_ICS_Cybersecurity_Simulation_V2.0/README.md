# SDN-Based Cybersecurity Framework for Industrial Control Systems

## Research Project

**Title:** Development of a Software Defined Network Based Cybersecurity Framework for Industrial Control Systems

**Authors:** Mupatiwa Zulu and Lukumba Phiri  
**Institution:** University of Zambia, School of Engineering

## 1. Overview

This repository provides the MATLAB simulation source code and reproducibility artefacts for evaluating an SDN-based cybersecurity framework for Industrial Control Systems (ICS).

The simulation models an ICS environment involving a Human-Machine Interface (HMI), engineering workstation and Programmable Logic Controller (PLC).

## 2. Software Requirements

- MATLAB R2024b (used for the reported results).
- MATLAB R2020a or later.
- Base MATLAB functions only.
- No additional MATLAB toolboxes required.

## 3. Simulation Configuration

- Simulation duration: 120 seconds.
- Simulation time step: 0.01 seconds.
- Monte Carlo runs: 30.
- Base random seed: 2026.
- Network bottleneck capacity: 1,000 packets/second.
- Buffer capacity: 200 packets.

## 4. Attack Scenarios

1. TCP SYN port scanning.
2. Modbus/TCP flooding.
3. TCP SYN flooding (spoofed).
4. HTTP flooding.

## 5. Comparison Modes

- Baseline: No security application.
- Static ACL: Static Access Control List protection.
- SDN-Sec: SDN-based detection and dynamic mitigation.

## 6. Evaluation Metrics

- Attack detection latency.
- Time to mitigation.
- Detection performance and false-positive rate.
- Legitimate HMI packet delivery.
- HMI packet loss.
- HMI communication latency and deadline misses.
- Threshold sensitivity.
- Controller resource utilisation.

## 7. Repository Contents

- `sdn_Code.m`: Main MATLAB simulation source code.
- `sdn_Code_REPRODUCIBILITY.m`: Simulation execution script.
- `Figure1` to `Figure9`: Generated simulation figures.
- `Table1` to `Table4`: Simulation parameters and summary results.
- `TableD1`: Individual Monte Carlo run results.
- `TableD3`: Threshold sensitivity results.

Supporting tables are supplied in Excel and CSV formats where applicable.

## 8. Running the Simulation

1. Download and extract the complete simulation package.
2. Open MATLAB.
3. Set the extracted project folder as the MATLAB Current Folder.
4. Execute:

```matlab
sdn_Code_REPRODUCIBILITY
```

The reproducibility script executes the authoritative simulation file, `sdn_Code.m`.

## 9. Simulation Limitations

This research uses a MATLAB-based simulation model. It does not represent deployment on a physical industrial network or a live SDN controller.

SDN monitoring, detection and mitigation operations are modelled through simulated network and controller behaviour.

Results should therefore be interpreted within the assumptions and limitations of the simulation environment.

## 10. Reproducibility and Citation

The complete source code and supporting research artefacts are archived in this repository and the associated Zenodo research record.

The Zenodo DOI will be provided following publication of the updated release.