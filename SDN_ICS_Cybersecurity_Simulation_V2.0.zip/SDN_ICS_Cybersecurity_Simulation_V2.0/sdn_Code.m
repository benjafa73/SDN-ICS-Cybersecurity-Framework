%% =========================================================================
% SDN-BASED CYBERSECURITY FRAMEWORK FOR INDUSTRIAL CONTROL SYSTEMS
% Revised discrete-time Monte Carlo simulation model  (v2.0)
%
% Manuscript:
% Development of a Software Defined Network Based Cybersecurity
% Framework for Industrial Control Systems
%
% Authors : Mupatiwa Zulu, Lukumba Phiri
%           University of Zambia, Department of Electrical and Electronic
%           Engineering
%
% WHAT THIS MODEL IS
%   A discrete-time (dt = 10 ms) Monte Carlo simulation of an SDN-protected
%   ICS segment (HMI, engineering workstation, PLC) under four attacks.
%   It is a simulation, NOT a measurement on a physical OpenFlow testbed.
%
% CHANGES FROM v1
%   1. No ground truth reaches the detector. The controller sees only
%      per-source flow statistics polled from the switch every T_poll and
%      applies ONE threshold set to every scenario. Whitelisted hosts are
%      monitored like any other host; the whitelist only selects the
%      RESPONSE (alert-only vs. drop rule), never whether an alarm fires.
%   2. Feature-based rules instead of a single total-rate threshold:
%        R1 distinct-port flow attempts/s          (reconnaissance)
%        R2 SYN/s with low handshake completion    (SYN flood)
%        R3 Modbus/TCP transactions/s              (protocol flood)
%        R4 HTTP requests/s                        (application flood)
%        R5 destination-level half-open SYN rate   (spoofed SYN flood)
%   3. Benign traffic that can legitimately trip the rules: bulk Modbus
%      reads and an occasional asset-inventory scan from the engineering
%      workstation. False positives are therefore possible and measured.
%   4. Mitigation effect is an OUTCOME. A per-source drop rule or a
%      per-destination SYN meter is installed after a stochastic FlowMod
%      delay (controller + control channel + TCAM install). The fraction
%      of attack traffic removed depends on detection latency.
%   5. The bottleneck (PLC communication module, 1000 pkt/s, 200-packet
%      buffer) saturates under flooding, so loss, queueing delay and
%      deadline misses are genuine outcomes.
%   6. Three comparison modes are evaluated using identical traffic:
%      BASELINE (no security app), STATIC ACL, and SDN-SEC (with the
%      detection/mitigation application).
%   7. Network metrics are for LEGITIMATE HMI polling traffic (delivery,
%      loss, RTT, 50 ms deadline misses), not totals including attack
%      packets.
%   8. Controller load is driven by packet-in events that actually reach
%      the controller after mitigation. "Memory %" is replaced by switch
%      flow-table occupancy, which is directly modelled.
%   9. 30 Monte Carlo runs; mean, SD and 95% CI (Student t). Threshold
%      sensitivity (ROC) sweep of a common scale factor 0.1x - 10x.
%      Time to mitigation is measured, defined as the moment >=90% of the
%      remaining attack packets are suppressed.
%  10. Figure fixes: no duplicated labels, loss in true %, labels placed
%      with XEndPoints, detection latency (not absolute time) annotated.
%
% REQUIREMENTS : MATLAB R2020a or later. Base MATLAB only (no toolboxes).
% OUTPUTS      : Figure1..Figure9 (PNG, 300 dpi), Table1..Table4 (.xlsx)
%                TableD1 and TableD3 (CSV and XLSX).
%% =========================================================================

clear; clc; close all;

%% =========================================================================
% 1. PARAMETERS
%% =========================================================================
P = struct();

% --- Simulation ---------------------------------------------------------
P.seed         = 2026;
P.T_sim        = 120;          % s
P.dt           = 0.01;         % s
P.attack_start = 45;           % s
P.attack_end   = 90;           % s
P.N_runs       = 30;

% Integer-indexed time base (avoids floating-point comparisons on t)
t      = (0:round(P.T_sim/P.dt)) * P.dt;
N      = numel(t);
k_atk0 = round(P.attack_start/P.dt) + 1;
k_atk1 = round(P.attack_end/P.dt);
atk_active = false(1,N);
atk_active(k_atk0:k_atk1) = true;
pre_attack = false(1,N);
pre_attack(1:k_atk0-1) = true;

% --- Bottleneck: PLC Ethernet communication module (traffic toward PLC) -
P.mu_plc      = 1000;          % service rate, packets/s
P.B_max       = 200;           % buffer, packets
P.tau_prop_ms = 0.50;          % propagation + switching, ms
P.tau_proc_ms = 1.32;          % PLC request processing, ms
P.deadline_ms = 50;            % HMI poll response deadline, ms

% --- Legitimate traffic -------------------------------------------------
P.hmi_poll_hz          = 10;   % HMI Modbus polling frequency (periodic)
P.hmi_reconnect_rate   = 0.01; % TCP reconnects/s
P.pkts_per_modbus      = 2;    % packets toward PLC per Modbus transaction
P.pkts_per_http        = 6;    % packets toward PLC per HTTP request (new TCP)
P.eng_modbus_rate      = 0.2;  % engineering WS background Modbus req/s
P.eng_modbus_conn_rate = 0.05; % new Modbus sessions/s
P.eng_http_rate        = 0.5;  % HTTP req/s (PLC web configuration pages)
P.eng_newport_rate     = 0.05; % connections to other services/s (SSH, etc.)
P.eng_burst_rate       = 1/60; % bulk-read bursts per s (Poisson)
P.eng_burst_dur        = [0.5 3.0];   % s, uniform
P.eng_burst_modbus     = [40 130];    % req/s during burst, uniform
P.eng_inventory_prob   = 0.30; % probability per run of an asset-inventory scan
P.eng_inventory_rate   = 30;   % ports/s
P.eng_inventory_dur    = 2.0;  % s
P.eng_inventory_open   = 0.20; % fraction of probed ports that are open

% --- Attacks (all directed at the PLC 10.0.0.2) ---------------------------
P.scan_rate         = 300;     % probes/s (SYN scan, distinct ports)
P.scan_open_frac    = 0.02;
P.modbus_flood_rate = 600;     % Modbus transactions/s (one TCP session)
P.syn_rate          = 4000;    % SYN/s in total
P.syn_spoof_frac    = 0.60;    % fraction from randomised spoofed sources
P.http_flood_rate   = 200;     % HTTP requests/s (full handshakes)

% --- Detection: ONE threshold set for ALL scenarios ----------------------
P.W            = 1.0;          % sliding window for rate features, s
P.T_poll       = 0.5;          % flow-statistics polling interval, s
P.stats_delay_ms = 5.0;        % mean stats-reply delay, ms (lognormal)
P.stats_delay_cv = 0.30;
P.th.ports            = 20;    % R1 distinct-port attempts/s per source
P.th.syn              = 100;   % R2 SYN/s per source ...
P.th.syn_complete_max = 0.30;  %    ... with completion ratio below this
P.th.modbus           = 100;   % R3 Modbus transactions/s per source
P.th.http             = 40;    % R4 HTTP requests/s per source
P.th.syn_agg          = 200;   % R5 SYN/s toward PLC (all sources) ...
P.th.agg_halfopen     = 0.70;  %    ... with half-open fraction above this
P.W_eval              = 1.0;   % window length for TPR/FPR accounting, s
P.roc_scales          = logspace(-1, 1, 25);   % includes 1.0 (index 13)

% --- Mitigation (FlowMod delay components, lognormal) --------------------
P.fm_ctrl_ms  = 2.0;           % controller decision
P.fm_chan_ms  = 1.5;           % control-channel transfer
P.fm_tcam_ms  = 9.0;           % switch rule install (TCAM)
P.fm_cv       = 0.30;
P.meter_syn_rate = 100;        % SYN meter toward PLC, packets/s
P.mit_target     = 0.90;       % 'mitigated' = >=90% of attack packets suppressed

% --- Controller / switch resources ---------------------------------------
P.ctrl_base_cpu     = 8.0;     % % CPU at idle
P.ctrl_max_pktin    = 10000;   % packet-in/s that saturate the controller
P.ctrl_poll_cpu     = 1.0;     % % CPU for the security app's stats polling
P.flow_idle_timeout = 5.0;     % s
P.flow_table_size   = 4000;    % entries
P.flow_static       = 20;      % pre-installed entries

% --- Hosts ---------------------------------------------------------------
SrcNames  = ["HMI", "Engineering WS", "Attacker"];
SrcIP     = ["10.0.0.1", "10.0.0.3", "10.0.0.100"];
Whitelist = ["10.0.0.1", "10.0.0.3"];       % HMI, engineering workstation
P.isWhite = ismember(SrcIP, Whitelist);     % used ONLY for response policy
nSrc = numel(SrcIP);
ATK  = 3;

% --- Scenarios -----------------------------------------------------------
AttackNames   = {'TCP Port Scan', 'Modbus/TCP Flood', 'TCP SYN Flood (spoofed)', 'HTTP Flood'};
RuleNames     = {'R1 port scan', 'R2 SYN', 'R3 Modbus rate', 'R4 HTTP rate', 'R5 dest. half-open SYN'};
ExpectedRules = {1, 3, [2 5], 4};
ModeNames = {'Baseline (no security app)', 'Static ACL', 'SDN-Sec'};
nAtk  = numel(AttackNames);
nMode = numel(ModeNames);
nRun  = P.N_runs;
nScale = numel(P.roc_scales);

fprintf('\n============================================================\n');
fprintf(' SDN-BASED ICS CYBERSECURITY FRAMEWORK SIMULATION  (v2.0)\n');
fprintf('============================================================\n');
fprintf('Simulation time      : %g s (dt = %g s)\n', P.T_sim, P.dt);
fprintf('Attack window        : %g - %g s\n', P.attack_start, P.attack_end);
fprintf('Monte Carlo runs     : %d (base seed %d)\n', nRun, P.seed);
fprintf('Bottleneck           : %g pkt/s, buffer %g pkts\n', P.mu_plc, P.B_max);
fprintf('Stats polling        : every %g s, window %g s\n', P.T_poll, P.W);
fprintf('============================================================\n\n');

%% =========================================================================
% 2. RESULT STORAGE
%% =========================================================================
f1 = NaN(nRun, nAtk);
R.det_lat = f1;  R.mit_lat = f1;  R.fm_delay = f1;  R.detected = f1;
R.correct = f1;  R.tpr = f1;      R.fpr = f1;       R.false_alerts = f1;
R.removed = NaN(nRun, nAtk, nMode);
R.ref_rtt = f1;  R.ref_loss = f1; R.ref_miss = f1;

f2 = NaN(nRun, nAtk, nMode);
R.deliv = f2;   R.loss = f2;     R.rtt_mean = f2;  R.rtt_p99 = f2;
R.miss = f2;    R.goodput = f2;  R.cpu_mean = f2;  R.cpu_peak = f2;
R.ft_peak = f2; R.ft_full = f2;

ROC.TP = zeros(nAtk, nScale);  ROC.FP = zeros(nAtk, nScale);
ROC.P  = zeros(nAtk, 1);       ROC.N  = zeros(nAtk, 1);

Trace = struct('rtt', cell(1,nAtk), 'loss', cell(1,nAtk), 't_det', cell(1,nAtk), 't_mit', cell(1,nAtk));

%% =========================================================================
% 3. MONTE CARLO SIMULATION
%% =========================================================================
tic;
for r = 1:nRun
    for a = 1:nAtk

        % Independent, reproducible stream per (run, scenario)
        rng(P.seed + 1000*r + a, 'twister');

        % ---- 3.1 Traffic (identical for both modes: paired design) -------
        F = generateTraffic(P, a, t, atk_active);

        % ---- 3.2 Controller view: polled per-source flow statistics ------
        D = pollFlowStats(F, P, t);

        % ---- 3.3 ROC sweep (detection only) --------------------------------
        for si = 1:nScale
            [fl, ~, ag] = applyRules(D, P, P.roc_scales(si));
            [tp_, np_, fp_, nn_] = windowCounts(fl, ag, D, P, ATK);
            ROC.TP(a,si) = ROC.TP(a,si) + tp_;
            ROC.FP(a,si) = ROC.FP(a,si) + fp_;
            if si == 1
                ROC.P(a) = ROC.P(a) + np_;
                ROC.N(a) = ROC.N(a) + nn_;
            end
        end

        % ---- 3.4 Nominal detection -----------------------------------------
        [flag, rule, aggflag] = applyRules(D, P, 1.0);
        [tp_, np_, fp_, nn_]  = windowCounts(flag, aggflag, D, P, ATK);
        R.tpr(r,a) = tp_ / np_;
        R.fpr(r,a) = fp_ / nn_;

        t_alarm = D.tp + D.reply_delay;     % alarm reaches the app

        % ---- 3.5 Response policy ------------------------------------------
        first_rule = zeros(1,nSrc);
        t_flag  = inf(1,nSrc);
        t_block = inf(1,nSrc);
        for s = 1:nSrc
            j = find(flag(s,:), 1, 'first');
            if ~isempty(j)
                t_flag(s)     = t_alarm(j);
                first_rule(s) = rule(s,j);
                if ~P.isWhite(s)            % whitelisted: alert only
                    t_block(s) = t_alarm(j) + flowmodDelay(P);
                end
            end
        end
        t_agg = inf;  t_meter = inf;
        j = find(aggflag, 1, 'first');
        if ~isempty(j)
            t_agg   = t_alarm(j);
            t_meter = t_agg + flowmodDelay(P);
        end

        % ---- 3.6 Detection latency and classification -----------------------
        [t_det, via] = min([t_flag(ATK), t_agg]);
        if isfinite(t_det) && t_det <= P.attack_end
            R.detected(r,a) = 1;
            R.det_lat(r,a)  = t_det - P.attack_start;
            if via == 1, cls = first_rule(ATK); else, cls = 5; end
            R.correct(r,a)  = double(ismember(cls, ExpectedRules{a}));
        else
            R.detected(r,a) = 0;
            R.correct(r,a)  = 0;
        end

        % False alerts: alarm onsets on benign (whitelisted) hosts, per hour
        fa = 0;
        for s = setdiff(1:nSrc, ATK)
            fa = fa + sum(diff([false, flag(s,:)]) == 1);
        end
        R.false_alerts(r,a) = fa / (P.T_sim/3600);

        % ---- 3.7 Traffic after mitigation (SDN-Sec mode) --------------------
        pk_eff = F.pkts;
        nf_eff = F.newflows;
        for s = 1:nSrc
            if isfinite(t_block(s))
                m = t >= t_block(s);
                pk_eff(s,m) = 0;            % drop rule at switch ingress
                nf_eff(s,m) = 0;            % proactive rule: no packet-in
            end
        end
        spoof_eff    = F.spoof_syn;
        spoof_pktin  = F.spoof_syn;
        if isfinite(t_meter)
            m = t >= t_meter;
            spoof_eff(m)   = min(spoof_eff(m), P.meter_syn_rate*P.dt);
            spoof_pktin(m) = 0;
        end

        atk_off = F.pkts(ATK,:) + F.spoof_syn;
        atk_eff = pk_eff(ATK,:) + spoof_eff;
        % Traffic removed by each mitigation mode
       R.removed(r,a,1) = 0;

       acl_attack_remaining = F.spoof_syn;
       R.removed(r,a,2) = 1 - sum(acl_attack_remaining(atk_active)) / max(sum(atk_off(atk_active)), eps);

       R.removed(r,a,3) = 1 - sum(atk_eff(atk_active)) / max(sum(atk_off(atk_active)), eps);

        % ---- 3.8 Time to effective mitigation -------------------------------
        % Earliest rule-installation time after which at least
        % P.mit_target of the remaining attack packets are suppressed.
        % (A definition of "mitigated", not an assumed effectiveness.)
        t_mit = NaN;
        acts  = sort([t_block(isfinite(t_block)), t_meter(isfinite(t_meter))]);
        for T_act = acts
            m = atk_active & t >= T_act;
            if any(m) && sum(atk_eff(m)) <= (1 - P.mit_target)*sum(atk_off(m))
                t_mit = T_act;
                break;
            end
        end
        if ~isnan(t_mit) && R.detected(r,a) == 1
            R.mit_lat(r,a)  = t_mit - P.attack_start;
            R.fm_delay(r,a) = t_mit - t_det;
        end

     % ---- 3.9 Network and controller performance, all modes --------------
     for md = 1:nMode

    if md == 1
        % BASELINE: no security filtering
        arrivals = sum(F.pkts,1) + F.spoof_syn;
        pktin    = sum(F.newflows,1) + F.spoof_syn;
        extraCPU = 0;
        nRules   = 0;

    elseif md == 2
        % STATIC ACL: fixed rule blocking the known attacker source
        acl_pkts = F.pkts;
        acl_flows = F.newflows;

        % Block attacker traffic from the beginning of the attack
        acl_pkts(3,atk_active) = 0;
        acl_flows(3,atk_active) = 0;

        % Spoofed SYN traffic is not blocked by the source-IP ACL
        arrivals = sum(acl_pkts,1) + F.spoof_syn;
        pktin    = sum(acl_flows,1) + F.spoof_syn;

        extraCPU = 0;
        nRules   = 1;

    else
        % SDN-SEC: dynamic detection and mitigation
        arrivals = sum(pk_eff,1) + spoof_eff;
        pktin    = sum(nf_eff,1) + spoof_pktin;
        extraCPU = P.ctrl_poll_cpu;
        nRules   = sum(isfinite([t_block, t_meter]));
    end

            Q = simQueue(arrivals, P);
            H = hmiMetrics(Q, F.hmi_poll, atk_active, P);
            C = controllerLoad(pktin, P, extraCPU, nRules);

            R.deliv(r,a,md)    = H.deliv * 100;
            R.loss(r,a,md)     = H.loss  * 100;
            R.rtt_mean(r,a,md) = H.rtt_mean;
            R.rtt_p99(r,a,md)  = H.rtt_p99;
            R.miss(r,a,md)     = H.miss  * 100;
            R.goodput(r,a,md)  = H.goodput;
            R.cpu_mean(r,a,md) = mean(C.cpu(atk_active));
            R.cpu_peak(r,a,md) = max(C.cpu(atk_active));
            R.ft_peak(r,a,md)  = max(C.ft(atk_active)) * 100;
            R.ft_full(r,a,md)  = mean(C.full(atk_active)) * 100;

            if md == 1      % no-attack reference from the pre-attack period
                Href = hmiMetrics(Q, F.hmi_poll, pre_attack, P);
                R.ref_rtt(r,a)  = Href.rtt_mean;
                R.ref_loss(r,a) = Href.loss * 100;
                R.ref_miss(r,a) = Href.miss * 100;
            end

            if r == 1       % traces for Figure 8
                Trace(a).rtt(md,:)  = P.tau_prop_ms + Q.delay_ms + P.tau_proc_ms;
                Trace(a).loss(md,:) = Q.p;
            end
        end
        if r == 1
            Trace(a).t_det = t_det;
            Trace(a).t_mit = t_mit;
        end
    end
    fprintf('  Run %2d/%d completed\n', r, nRun);
end
fprintf('\nSimulation completed in %.1f s\n', toc);



%% =========================================================================
% 4. STATISTICAL SUMMARY (mean, SD, 95% CI)
%% =========================================================================
S.det   = summarize(R.det_lat * 1000);       % ms
S.mit   = summarize(R.mit_lat * 1000);       % ms
S.fm    = summarize(R.fm_delay * 1000);      % ms
S.dr    = summarize(R.detected * 100);
S.cls   = summarize(R.correct * 100);
S.tpr   = summarize(R.tpr * 100);
S.fpr   = summarize(R.fpr * 100);
S.fa    = summarize(R.false_alerts);
S.rem   = summarize(R.removed * 100);

S.deliv = summarize(R.deliv);    S.loss = summarize(R.loss);
S.rtt   = summarize(R.rtt_mean); S.p99  = summarize(R.rtt_p99);
S.miss  = summarize(R.miss);     S.gp   = summarize(R.goodput);
S.cpu   = summarize(R.cpu_mean); S.cpuP = summarize(R.cpu_peak);
S.ftP   = summarize(R.ft_peak);  S.ftF  = summarize(R.ft_full);

Ref.rtt  = summarize(R.ref_rtt(:));
Ref.loss = summarize(R.ref_loss(:));
Ref.miss = summarize(R.ref_miss(:));

ROC.TPR = ROC.TP ./ ROC.P * 100;
ROC.FPR = ROC.FP ./ ROC.N * 100;

pm = char(177);

%% Appendix D.3: Export threshold sensitivity results

ThresholdSensitivity = table();

for a = 1:nAtk
    temp = table(repmat(string(AttackNames{a}), nScale, 1), P.roc_scales(:), ROC.TPR(a,:)', ROC.FPR(a,:)', 'VariableNames', { 'Attack', 'ThresholdScale', 'TPR_pct', 'FPR_pct'});

    ThresholdSensitivity = [ThresholdSensitivity; temp];
end

writetable(ThresholdSensitivity, 'TableD3_ThresholdSensitivity.xlsx');

writetable(ThresholdSensitivity, 'TableD3_ThresholdSensitivity.csv');

disp(ThresholdSensitivity);

%% =========================================================================
% 5. CONSOLE RESULTS
%% =========================================================================
fprintf('\n');
fprintf('==============================================================================================\n');
fprintf(' DETECTION AND MITIGATION (mean %s 95%% CI, n = %d)\n', pm, nRun);
fprintf('==============================================================================================\n');
fprintf('%-24s %-16s %-16s %8s %8s %8s %9s %9s\n', 'Attack', 'Detect (ms)', ...
    'Mitigate (ms)', 'TPR %', 'FPR %', 'FA/h', 'Class. %', 'Removed %');
fprintf('----------------------------------------------------------------------------------------------\n');
remMean = reshape(S.rem.mean, [], nMode);
for a = 1:nAtk
    fprintf('%-24s %6.1f %s %-6.1f %6.1f %s %-6.1f %8.2f %8.3f %8.1f %9.1f %9.2f\n', AttackNames{a}, S.det.mean(a), pm, S.det.ci(a), S.mit.mean(a), pm, S.mit.ci(a), S.tpr.mean(a), S.fpr.mean(a), S.fa.mean(a), S.cls.mean(a), remMean(a,3));
end
fprintf('==============================================================================================\n');

fprintf('\n');
fprintf('==============================================================================================\n');
fprintf(' LEGITIMATE HMI TRAFFIC DURING ATTACK: BASELINE vs STATIC ACL vs SDN-SEC (mean over runs)\n');
fprintf('==============================================================================================\n');
fprintf('%-24s %-10s %10s %9s %11s %11s %10s %8s %9s\n', 'Attack', 'Mode', ...
    'Deliv. %', 'Loss %', 'RTT (ms)', 'p99 (ms)', 'Miss %', 'CPU %', 'FT pk %');
fprintf('----------------------------------------------------------------------------------------------\n');
fprintf('%-24s %-10s %10.2f %9.3f %11.3f %11s %10.3f %8s %9s\n', 'No attack (reference)', ...
    '-', 100 - Ref.loss.mean, Ref.loss.mean, Ref.rtt.mean, '-', Ref.miss.mean, '-', '-');
shortMode = {'Baseline', 'Static ACL', 'SDN-Sec'};
for a = 1:nAtk
    for md = 1:nMode
        fprintf('%-24s %-10s %10.2f %9.3f %11.3f %11.3f %10.3f %8.2f %9.2f\n', ...
            AttackNames{a}, shortMode{md}, S.deliv.mean(1,a,md), S.loss.mean(1,a,md), ...
            S.rtt.mean(1,a,md), S.p99.mean(1,a,md), S.miss.mean(1,a,md), ...
            S.cpu.mean(1,a,md), S.ftP.mean(1,a,md));
    end
end
fprintf('==============================================================================================\n');

%% =========================================================================
% 6. FIGURES
%% =========================================================================
cBase = [0.80 0.33 0.10];   % Baseline
cACL  = [0.85 0.55 0.20];   % Static ACL
cSec  = [0.00 0.45 0.74];   % SDN-Sec
cDet  = [0.30 0.30 0.30];
fs    = 9;

% ---------------- Figure 1: detection latency ----------------------------
figure(1); clf;
b = bar(S.det.mean(:), 'FaceColor', cSec); hold on;
errorbar(b.XEndPoints, S.det.mean, S.det.ci, 'k', 'LineStyle', 'none', 'LineWidth', 1.2);
addBarLabels(b, (S.det.mean + S.det.ci)' + 0.02*max(S.det.mean + S.det.ci), '%.0f ms', fs);
setCategoryAxis(AttackNames);
ylabel('Detection latency (ms)'); xlabel('Attack scenario');
title('Detection latency (mean, 95% CI)');
ylim([0 1.2*max(S.det.mean + S.det.ci)]);
grid on; box on;
ax = gca;
ax.Toolbar.Visible = 'off';
exportgraphics(gcf, 'Figure1_DetectionLatency.png', 'Resolution', 300);

% ---------------- Figure 2: time to mitigation (stacked) -----------------
figure(2); clf;
stackData = [S.det.mean(:), S.fm.mean(:)];
b = bar(stackData, 'stacked'); hold on;
b(1).FaceColor = cDet; b(2).FaceColor = cSec;
xt = b(2).XEndPoints;
errorbar(xt, S.mit.mean, S.mit.ci, 'k', 'LineStyle', 'none', 'LineWidth', 1.2);
ytop = S.mit.mean + S.mit.ci;
for i = 1:nAtk
    text(xt(i), ytop(i) + 0.02*max(ytop), sprintf('%.0f ms', S.mit.mean(i)), ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
        'FontWeight', 'bold', 'FontSize', fs);
end
setCategoryAxis(AttackNames);
ylabel('Time from attack onset (ms)'); xlabel('Attack scenario');
title('Time to mitigation = detection + FlowMod installation');
legend({'Detection latency', 'FlowMod installation'}, 'Location', 'northwest');
ylim([0 1.2*max(ytop)]);
grid on; box on;
ax = gca;
ax.Toolbar.Visible = 'off';
exportgraphics(gcf, 'Figure2_TimeToMitigation.png', 'Resolution', 300);

% ---------------- Figure 3: TPR, FPR, classification ---------------------
figure(3); clf;
perf   = [S.tpr.mean(:), S.fpr.mean(:), S.cls.mean(:)];
perfCI = [S.tpr.ci(:),   S.fpr.ci(:),   S.cls.ci(:)];
b = bar(perf); hold on;
b(1).FaceColor = cSec; b(2).FaceColor = cBase; b(3).FaceColor = [0.47 0.67 0.19];
for j = 1:3
    errorbar(b(j).XEndPoints, perf(:,j), perfCI(:,j), 'k', 'LineStyle', 'none');
end
addBarLabels(b, perf + perfCI + 1.5, '%.1f', fs-1);
setCategoryAxis(AttackNames);
ylabel('Percentage (%)'); xlabel('Attack scenario');
title('Window-level detection performance (1 s windows)');
legend({'True-positive rate', 'False-positive rate', 'Correct attack class'}, ...
    'Location', 'southoutside', 'Orientation', 'horizontal');
ylim([0 125]);
grid on; box on;
ax = gca;
ax.Toolbar.Visible = 'off';
exportgraphics(gcf, 'Figure3_DetectionPerformance.png', 'Resolution', 300);

% ---------------- Figure 4: HMI delivery ratio ---------------------------
figure(4); clf;
[mu, ci] = modePair(S.deliv);
b = groupedBars(mu, ci, cBase, cACL, cSec);
addBarLabels(b, mu + ci + 2, '%.1f%%', fs-1);
yline(100 - Ref.loss.mean, ':', 'LineWidth', 1.0, 'HandleVisibility', 'off');
setCategoryAxis(AttackNames);
ylabel('HMI transactions delivered (%)'); xlabel('Attack scenario');
title('Legitimate HMI traffic delivered during the attack');
legend(ModeNames, 'Location', 'southoutside', 'Orientation', 'horizontal');
ylim([0 125]);
grid on; box on;
ax = gca;
ax.Toolbar.Visible = 'off';
exportgraphics(gcf, 'Figure4_HMIDelivery.png', 'Resolution', 300);

% ---------------- Figure 5: HMI packet loss (true %) ---------------------
figure(5); clf;
[mu, ci] = modePair(S.loss);
b = groupedBars(mu, ci, cBase, cACL, cSec);
addBarLabels(b, mu + ci + 0.02*max(mu(:) + ci(:)) + 0.05, '%.2f%%', fs-1);
setCategoryAxis(AttackNames);
ylabel('HMI packet loss (%)'); xlabel('Attack scenario');
title('Legitimate HMI packet loss during the attack');
legend(ModeNames, 'Location', 'northwest');
ylim([0 max(1, 1.2*max(mu(:) + ci(:)))]);
grid on; box on;
ax = gca;
ax.Toolbar.Visible = 'off';
exportgraphics(gcf, 'Figure5_HMIPacketLoss.png', 'Resolution', 300);

% ---------------- Figure 6: HMI latency and deadline misses --------------
figure(6); clf;
set(gcf, 'Position', [100 100 1000 420]);

subplot(1,2,1);
[mu, ci] = modePair(S.rtt);
b = groupedBars(mu, ci, cBase, cACL, cSec);
set(gca, 'YScale', 'log');

for j = 1:numel(b)
    b(j).BaseValue = 1;
end

addBarLabels(b, (mu + ci) * 1.15, '%.1f', fs-1);
yline(P.deadline_ms, '--', sprintf('%g ms deadline', P.deadline_ms), ...
    'LineWidth', 1.0, 'HandleVisibility', 'off');
setCategoryAxis(AttackNames);
ylabel('Mean HMI round-trip time (ms, log scale)');
title('(a) HMI round-trip time');
ylim([1 1000]);
legend(ModeNames, 'Location', 'northwest');
grid on; box on;

subplot(1,2,2);
[mu, ci] = modePair(S.miss);
b = groupedBars(mu, ci, cBase, cACL, cSec);
addBarLabels(b, mu + ci + 2, '%.1f', fs-1);
setCategoryAxis(AttackNames);
ylabel('HMI polls lost or late (%)');
title(sprintf('(b) Deadline misses (> %g ms or lost)', P.deadline_ms));
ylim([0 115]);
legend(ModeNames, 'Location', 'northwest');
grid on; box on;

ax = gca;
ax.Toolbar.Visible = 'off';
exportgraphics(gcf, 'Figure6_HMILatencyDeadline.png', 'Resolution', 300);

% ---------------- Figure 7: threshold sensitivity (ROC sweep) -----------
% All rate thresholds are multiplied by a common factor (0.1x - 10x).
figure(7); clf;
set(gcf, 'Position', [100 100 1000 420]);
mk = {'o', 's', '^', 'd'};
subplot(1,2,1); hold on;
for a = 1:nAtk
    semilogx(P.roc_scales, ROC.TPR(a,:), ['-' mk{a}], 'LineWidth', 1.4, 'MarkerSize', 4, 'DisplayName', AttackNames{a});
end
set(gca, 'XScale', 'log');
xline(1, 'k--', 'nominal', 'HandleVisibility', 'off');
xlabel('Threshold scale factor'); ylabel('True-positive rate (%)');
title('(a) Detection vs. threshold');
legend('Location', 'southwest');
xlim([min(P.roc_scales) max(P.roc_scales)]); ylim([0 105]);
grid on; box on;

subplot(1,2,2); hold on;
for a = 1:nAtk
    semilogx(P.roc_scales, ROC.FPR(a,:), ['-' mk{a}], 'LineWidth', 1.4, 'MarkerSize', 4, 'DisplayName', AttackNames{a});
end
set(gca, 'XScale', 'log');
xline(1, 'k--', 'nominal', 'HandleVisibility', 'off');
xlabel('Threshold scale factor'); ylabel('False-positive rate (%)');
title('(b) False positives vs. threshold');
xlim([min(P.roc_scales) max(P.roc_scales)]);
ylim([0 max(5, 1.1*max(ROC.FPR(:)))]);
grid on; box on;
ax = gca;
ax.Toolbar.Visible = 'off';
exportgraphics(gcf, 'Figure7_ThresholdSensitivity.png', 'Resolution', 300);

% ---------------- Figure 8: time-domain response (run 1) -----------------
figure(8); clf;
set(gcf, 'Position', [100 100 1100 700]);

for a = 1:nAtk
    subplot(2,2,a);
    hold on;

    semilogy(t, Trace(a).rtt(1,:), 'Color', cBase, 'LineWidth', 1.0);
    semilogy(t, Trace(a).rtt(2,:), 'Color', cACL,  'LineWidth', 1.2);
    semilogy(t, Trace(a).rtt(3,:), 'Color', cSec,  'LineWidth', 1.4);

    set(gca, 'YScale', 'log');

    xline(P.attack_start, 'k--', 'HandleVisibility', 'off');
    xline(P.attack_end,   'k--', 'HandleVisibility', 'off');
    yline(P.deadline_ms, ':', 'HandleVisibility', 'off');

    if isfinite(Trace(a).t_det)
        xline(Trace(a).t_det, '-', sprintf('detected +%.0f ms', 1000*(Trace(a).t_det - P.attack_start)), 'Color', cDet, 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off');
    end

    xlim([P.attack_start - 5, P.attack_end + 5]);
    ylim([1 500]);
    xlabel('Time (s)');
    ylabel('HMI RTT (ms)');
    title(AttackNames{a});

    if a == 1
        legend({'Baseline', 'Static ACL', 'SDN-Sec'}, 'Location', 'northeast');
    end

    grid on;
    box on;
end

sgtitle('Instantaneous HMI round-trip time, run 1');
ax = gca;
ax.Toolbar.Visible = 'off';
exportgraphics(gcf, 'Figure8_TimeDomainResponse.png', 'Resolution', 300);

% ---------------- Figure 9: controller and switch resources --------------
figure(9); clf;
set(gcf, 'Position', [100 100 1000 420]);

subplot(1,2,1);
[mu, ci] = modePair(S.cpu);
b = groupedBars(mu, ci, cBase, cACL, cSec);
addBarLabels(b, mu + ci + 1.5, '%.1f', fs-1);
setCategoryAxis(AttackNames);
ylabel('Mean controller CPU (%)');
title('(a) Controller load (packet-in driven)');
ylim([0 max(30, 1.25*max(mu(:) + ci(:)))]);
legend(ModeNames, 'Location', 'northwest');
grid on; box on;

subplot(1,2,2);
[mu, ci] = modePair(S.ftP);
b = groupedBars(mu, ci, cBase, cACL, cSec);
addBarLabels(b, mu + ci + 2, '%.1f', fs-1);
setCategoryAxis(AttackNames);
ylabel('Peak flow-table occupancy (%)');
title(sprintf('(b) Switch flow table (%d entries)', P.flow_table_size));
ylim([0 115]);
legend(ModeNames, 'Location', 'northwest');
grid on; box on;

ax = gca;
ax.Toolbar.Visible = 'off';
exportgraphics(gcf, 'Figure9_ControllerResources.png', 'Resolution', 300);

%% =========================================================================
% 7. MANUSCRIPT TABLES
%% =========================================================================

% ---------------- Table 1: parameters ------------------------------------
T1 = {
 'Simulation time',                P.T_sim,             's',        'Design choice'
 'Time step',                      P.dt,                's',        'Design choice'
 'Attack window',                  sprintf('%g-%g', P.attack_start, P.attack_end), 's', 'Design choice'
 'Monte Carlo runs',               P.N_runs,            '-',        'Design choice'
 'PLC comms service rate',         P.mu_plc,            'pkt/s',    'Assumed (embedded PLC Ethernet module)'
 'PLC comms buffer',               P.B_max,             'packets',  'Assumed'
 'Propagation + switching delay',  P.tau_prop_ms,       'ms',       'Assumed'
 'PLC processing delay',           P.tau_proc_ms,       'ms',       'Assumed'
 'HMI deadline',                   P.deadline_ms,       'ms',       'Assumed control requirement'
 'HMI polling frequency',          P.hmi_poll_hz,       'Hz',       'Assumed'
 'Eng. WS bulk-read bursts',       P.eng_burst_rate,    '1/s',      'Assumed benign workload'
 'Eng. WS burst Modbus rate',      sprintf('%g-%g', P.eng_burst_modbus), 'req/s', 'Assumed benign workload'
 'Asset-inventory scan prob.',     P.eng_inventory_prob,'per run',  'Assumed benign workload'
 'Port-scan rate',                 P.scan_rate,         'probes/s', 'Attack model'
 'Modbus flood rate',              P.modbus_flood_rate, 'req/s',    'Attack model'
 'SYN flood rate',                 P.syn_rate,          'SYN/s',    'Attack model'
 'SYN spoofed fraction',           P.syn_spoof_frac,    '-',        'Attack model'
 'HTTP flood rate',                P.http_flood_rate,   'req/s',    'Attack model'
 'Feature window',                 P.W,                 's',        'Detector design'
 'Stats polling interval',         P.T_poll,            's',        'Detector design'
 'R1 distinct-port threshold',     P.th.ports,          'ports/s',  'Detector design'
 'R2 SYN threshold',               P.th.syn,            'SYN/s',    'Detector design'
 'R2 max completion ratio',        P.th.syn_complete_max,'-',       'Detector design'
 'R3 Modbus threshold',            P.th.modbus,         'req/s',    'Detector design'
 'R4 HTTP threshold',              P.th.http,           'req/s',    'Detector design'
 'R5 destination SYN threshold',   P.th.syn_agg,        'SYN/s',    'Detector design'
 'R5 min half-open fraction',      P.th.agg_halfopen,   '-',        'Detector design'
 'FlowMod delay (mean)',           P.fm_ctrl_ms + P.fm_chan_ms + P.fm_tcam_ms, 'ms', 'Assumed, lognormal components'
 'SYN meter rate',                 P.meter_syn_rate,    'pkt/s',    'Mitigation design'
 'Mitigated criterion',            P.mit_target*100,    '% suppressed', 'Metric definition'
 'Controller packet-in capacity',  P.ctrl_max_pktin,    'pkt-in/s', 'Assumed'
 'Flow-table size',                P.flow_table_size,   'entries',  'Assumed'
 'Flow idle timeout',              P.flow_idle_timeout, 's',        'Assumed'
 };
T1(:,2) = cellfun(@(v) num2strIfNum(v), T1(:,2), 'UniformOutput', false);
Table1 = cell2table(T1, 'VariableNames', {'Parameter', 'Value', 'Unit', 'Basis'});
writetable(Table1, 'Table1_SimulationParameters.xlsx');

% ---------------- Table 2: detection and mitigation ----------------------
% ---------------- Table 2: detection and mitigation ----------------------
fmt = @(m, c, d) sprintf(['%.' num2str(d) 'f ' pm ' %.' num2str(d) 'f'], m, c);

remMean = reshape(S.rem.mean, [], nMode);

Table2 = table(AttackNames(:), arrayfun(@(i) fmt(S.det.mean(i), S.det.ci(i), 1), (1:nAtk)', 'UniformOutput', false), arrayfun(@(i) fmt(S.mit.mean(i), S.mit.ci(i), 1), (1:nAtk)', 'UniformOutput', false), round(S.dr.mean(:), 1), round(S.tpr.mean(:), 2), round(S.fpr.mean(:), 3), round(S.fa.mean(:), 1), round(S.cls.mean(:), 1), round(remMean(:,3), 2), ...
    'VariableNames', {'Attack', 'DetectionLatency_ms_CI95', 'TimeToMitigation_ms_CI95', 'RunsDetected_pct', 'WindowTPR_pct', 'WindowFPR_pct', 'FalseAlerts_per_h', 'CorrectClass_pct', 'AttackTrafficRemoved_pct'});

writetable(Table2, 'Table2_DetectionMitigation.xlsx');

% ---------------- Table 3: legitimate HMI traffic, baseline vs SDN-Sec ---
rows = cell(0,7);
rows(end+1,:) = {'No attack (reference)', '-', ...
    sprintf('%.2f', 100 - Ref.loss.mean), sprintf('%.3f', Ref.loss.mean), ...
    fmt(Ref.rtt.mean, Ref.rtt.ci, 3), '-', sprintf('%.3f', Ref.miss.mean)};
for a = 1:nAtk
    for md = 1:nMode
        rows(end+1,:) = {AttackNames{a}, shortMode{md}, ...
            fmt(S.deliv.mean(1,a,md), S.deliv.ci(1,a,md), 2), ...
            fmt(S.loss.mean(1,a,md),  S.loss.ci(1,a,md), 3), ...
            fmt(S.rtt.mean(1,a,md),   S.rtt.ci(1,a,md), 3), ...
            fmt(S.p99.mean(1,a,md),   S.p99.ci(1,a,md), 2), ...
            fmt(S.miss.mean(1,a,md),  S.miss.ci(1,a,md), 2)}; %#ok<SAGROW>
    end
end
Table3 = cell2table(rows, 'VariableNames', {'Attack', 'Mode', 'HMIDelivered_pct', ...
    'HMILoss_pct', 'HMIMeanRTT_ms', 'HMIp99RTT_ms', 'DeadlineMiss_pct'});
writetable(Table3, 'Table3_HMIPerformance_Baseline_vs_StaticACL_vs_SDNSec.xlsx');

% ---------------- Table 4: controller and switch resources ---------------
rows = cell(0,6);
for a = 1:nAtk
    for md = 1:nMode
        rows(end+1,:) = {AttackNames{a}, shortMode{md}, ...
            fmt(S.cpu.mean(1,a,md),  S.cpu.ci(1,a,md), 2), ...
            fmt(S.cpuP.mean(1,a,md), S.cpuP.ci(1,a,md), 2), ...
            fmt(S.ftP.mean(1,a,md),  S.ftP.ci(1,a,md), 2), ...
            fmt(S.ftF.mean(1,a,md),  S.ftF.ci(1,a,md), 2)}; %#ok<SAGROW>
    end
end
Table4 = cell2table(rows, 'VariableNames', {'Attack', 'Mode', 'MeanCPU_pct', ...
    'PeakCPU_pct', 'PeakFlowTable_pct', 'FlowTableFull_time_pct'});
writetable(Table4, 'Table4_ControllerResources.xlsx');


% =========================================================================
% TABLE D1: INDIVIDUAL MONTE CARLO RUN RESULTS
% One record per run, attack scenario and operating mode.
% Baseline detection-related fields are NaN because no security app runs.
% =========================================================================

nRecords = nRun * nAtk * nMode;

RunNumber       = zeros(nRecords,1);
RunSeed         = zeros(nRecords,1);
Attack          = cell(nRecords,1);
Mode            = cell(nRecords,1);

DetectionLatency_ms    = NaN(nRecords,1);
MitigationLatency_ms   = NaN(nRecords,1);
FlowModDelay_ms        = NaN(nRecords,1);
AttackDetected_pct     = NaN(nRecords,1);
CorrectClassification_pct = NaN(nRecords,1);
WindowTPR_pct          = NaN(nRecords,1);
WindowFPR_pct          = NaN(nRecords,1);
FalseAlerts_per_hour   = NaN(nRecords,1);
AttackTrafficRemoved_pct = NaN(nRecords,1);

HMIDelivered_pct       = zeros(nRecords,1);
HMILoss_pct            = zeros(nRecords,1);
HMI_MeanRTT_ms         = zeros(nRecords,1);
HMI_P99RTT_ms          = zeros(nRecords,1);
HMI_DeadlineMiss_pct   = zeros(nRecords,1);
HMI_Goodput            = zeros(nRecords,1);

MeanCPU_pct            = zeros(nRecords,1);
PeakCPU_pct            = zeros(nRecords,1);
PeakFlowTable_pct      = zeros(nRecords,1);
FlowTableFull_time_pct = zeros(nRecords,1);

idx = 0;

for r = 1:nRun
    for a = 1:nAtk
        for md = 1:nMode

            idx = idx + 1;

            RunNumber(idx) = r;
            RunSeed(idx)   = P.seed + 1000*r + a;
            Attack{idx}    = AttackNames{a};
            Mode{idx}      = shortMode{md};

            % Network and controller results for all three operating modes
            HMIDelivered_pct(idx)       = R.deliv(r,a,md);
            HMILoss_pct(idx)            = R.loss(r,a,md);
            HMI_MeanRTT_ms(idx)         = R.rtt_mean(r,a,md);
            HMI_P99RTT_ms(idx)          = R.rtt_p99(r,a,md);
            HMI_DeadlineMiss_pct(idx)   = R.miss(r,a,md);
            HMI_Goodput(idx)            = R.goodput(r,a,md);

            MeanCPU_pct(idx)            = R.cpu_mean(r,a,md);
            PeakCPU_pct(idx)            = R.cpu_peak(r,a,md);
            PeakFlowTable_pct(idx)      = R.ft_peak(r,a,md);
            FlowTableFull_time_pct(idx) = R.ft_full(r,a,md);

% Detection and mitigation are applicable to SDN-Sec only
if md == 3
    DetectionLatency_ms(idx) = R.det_lat(r,a) * 1000;
    MitigationLatency_ms(idx) = R.mit_lat(r,a) * 1000;
    FlowModDelay_ms(idx) = R.fm_delay(r,a) * 1000;

    AttackDetected_pct(idx) = R.detected(r,a) * 100;
    CorrectClassification_pct(idx) = R.correct(r,a) * 100;

    WindowTPR_pct(idx) = R.tpr(r,a) * 100;
    WindowFPR_pct(idx) = R.fpr(r,a) * 100;

    FalseAlerts_per_hour(idx) = R.false_alerts(r,a);
else
    DetectionLatency_ms(idx) = NaN;
    MitigationLatency_ms(idx) = NaN;
    FlowModDelay_ms(idx) = NaN;

    AttackDetected_pct(idx) = NaN;
    CorrectClassification_pct(idx) = NaN;

    WindowTPR_pct(idx) = NaN;
    WindowFPR_pct(idx) = NaN;

    FalseAlerts_per_hour(idx) = NaN;
end

% Attack traffic removed: use the result for the current mode
AttackTrafficRemoved_pct(idx) = R.removed(r,a,md) * 100;

        end
    end
end

% Create the individual-run results table
TableD1 = table(RunNumber, RunSeed, Attack, Mode, ...
    DetectionLatency_ms, MitigationLatency_ms, FlowModDelay_ms, ...
    AttackDetected_pct, CorrectClassification_pct, ...
    WindowTPR_pct, WindowFPR_pct, FalseAlerts_per_hour, ...
    AttackTrafficRemoved_pct, ...
    HMIDelivered_pct, HMILoss_pct, HMI_MeanRTT_ms, ...
    HMI_P99RTT_ms, HMI_DeadlineMiss_pct, HMI_Goodput, ...
    MeanCPU_pct, PeakCPU_pct, PeakFlowTable_pct, ...
    FlowTableFull_time_pct);

% Export to CSV and Excel
writetable(TableD1, 'TableD1_IndividualRunResults.csv');
writetable(TableD1, 'TableD1_IndividualRunResults.xlsx');

fprintf('\nTable D1: Individual Monte Carlo results exported.\n');
fprintf('Records exported: %d\n', height(TableD1));


fprintf('\nFigures 1-9 (PNG) and Tables 1-4 (XLSX) written to %s\n', pwd);
disp(Table2);
disp(Table3);
disp(Table4);

%% =========================================================================
% 8. LOCAL FUNCTIONS
%% =========================================================================

function F = generateTraffic(P, a, t, atk_active)
% Per-source event counts per time step (rows: HMI, Eng. WS, Attacker).
N  = numel(t);
dt = P.dt;
Z  = zeros(3, N);
F.modbus = Z; F.http = Z; F.syn = Z; F.syncomp = Z;
F.ports  = Z; F.newflows = Z; F.pkts = Z;
F.spoof_syn = zeros(1, N);
one = ones(1, N);

% --- HMI: strictly periodic Modbus polling on a persistent session -------
period = round(1/(P.hmi_poll_hz*dt));
phase  = randi(period) - 1;
poll   = double(mod((0:N-1) - phase, period) == 0);
recon  = poissrnd_base(P.hmi_reconnect_rate*dt*one);
F.hmi_poll       = poll > 0;
F.modbus(1,:)    = poll;
F.syn(1,:)       = recon;
F.syncomp(1,:)   = recon;
F.newflows(1,:)  = recon;
F.pkts(1,:)      = P.pkts_per_modbus*poll + recon;

% --- Engineering workstation (whitelisted, bursty, sometimes scan-like) --
lam_mb = P.eng_modbus_rate*one;
nb = poissrnd_base(P.eng_burst_rate*P.T_sim);
for i = 1:nb
    ts   = rand*P.T_sim;
    dur  = P.eng_burst_dur(1) + rand*diff(P.eng_burst_dur);
    rate = P.eng_burst_modbus(1) + rand*diff(P.eng_burst_modbus);
    idx  = t >= ts & t < ts + dur;
    lam_mb(idx) = lam_mb(idx) + rate;
end
mb     = poissrnd_base(lam_mb*dt);
ht     = poissrnd_base(P.eng_http_rate*dt*one);
conn   = poissrnd_base(P.eng_modbus_conn_rate*dt*one);
newsvc = poissrnd_base(P.eng_newport_rate*dt*one);
lam_inv = zeros(1, N);
if rand < P.eng_inventory_prob
    ts = 5 + rand*(P.T_sim - 10 - P.eng_inventory_dur);
    lam_inv(t >= ts & t < ts + P.eng_inventory_dur) = P.eng_inventory_rate;
end
inv     = poissrnd_base(lam_inv*dt);
invopen = min(inv, poissrnd_base(lam_inv*P.eng_inventory_open*dt));
F.modbus(2,:)   = mb;
F.http(2,:)     = ht;
F.syn(2,:)      = ht + conn + newsvc + inv;
F.syncomp(2,:)  = ht + conn + newsvc + invopen;
F.ports(2,:)    = newsvc + inv;
F.newflows(2,:) = F.syn(2,:);
F.pkts(2,:)     = P.pkts_per_modbus*mb + P.pkts_per_http*ht + conn + newsvc + inv;

% --- Attacker (traffic only inside the attack window) --------------------
A = double(atk_active);
switch a
    case 1  % SYN port scan across distinct ports
        pr = poissrnd_base(P.scan_rate*dt*A);
        op = min(pr, poissrnd_base(P.scan_rate*P.scan_open_frac*dt*A));
        F.ports(3,:) = pr;  F.syn(3,:) = pr;  F.syncomp(3,:) = op;
        F.newflows(3,:) = pr;  F.pkts(3,:) = pr;
    case 2  % Modbus/TCP flood over one established session
        mb = poissrnd_base(P.modbus_flood_rate*dt*A);
        k0 = find(A, 1, 'first');
        F.modbus(3,:) = mb;
        F.syn(3,k0) = 1;  F.syncomp(3,k0) = 1;  F.newflows(3,k0) = 1;
        F.pkts(3,:) = P.pkts_per_modbus*mb;
        F.pkts(3,k0) = F.pkts(3,k0) + 1;
    case 3  % SYN flood: part from attacker IP, part from spoofed sources
        s_real = poissrnd_base(P.syn_rate*(1 - P.syn_spoof_frac)*dt*A);
        s_spf  = poissrnd_base(P.syn_rate*P.syn_spoof_frac*dt*A);
        F.syn(3,:) = s_real;  F.newflows(3,:) = s_real;  F.pkts(3,:) = s_real;
        F.spoof_syn = s_spf;  % spread over many IPs: invisible per source
    case 4  % HTTP flood with complete handshakes
        ht = poissrnd_base(P.http_flood_rate*dt*A);
        F.http(3,:) = ht;  F.syn(3,:) = ht;  F.syncomp(3,:) = ht;
        F.newflows(3,:) = ht;  F.pkts(3,:) = P.pkts_per_http*ht;
end
end

function D = pollFlowStats(F, P, t)
% Sliding-window rates (per s) as seen by the controller at each poll.
% Drop rules keep counting matched packets, so features use offered load.
M    = round(P.W/P.dt);
ph   = rand*P.T_poll;
tp   = ph:P.T_poll:t(end);
kp   = round(tp/P.dt) + 1;
rate = @(x) movsum(x, [M-1 0], 2) / P.W;
pick = @(x) x(:, kp);
D.kp = kp;  D.tp = t(kp);  D.nPoll = numel(kp);
D.ports   = pick(rate(F.ports));
D.syn     = pick(rate(F.syn));
D.syncomp = pick(rate(F.syncomp));
D.modbus  = pick(rate(F.modbus));
D.http    = pick(rate(F.http));
D.agg_syn  = pick(rate(sum(F.syn,1) + F.spoof_syn));
D.agg_comp = pick(rate(sum(F.syncomp,1)));
D.reply_delay = lognrnd_base(P.stats_delay_ms, P.stats_delay_cv, [1 D.nPoll]) / 1000;
end

function [flag, rule, aggflag] = applyRules(D, P, s)
% One rule set for every scenario; s scales all rate thresholds (ROC).
th   = P.th;
comp = D.syncomp ./ max(D.syn, eps);
Rr = false([size(D.syn), 4]);
Rr(:,:,1) = D.ports  >= s*th.ports;
Rr(:,:,2) = D.syn    >= s*th.syn & comp < th.syn_complete_max;
Rr(:,:,3) = D.modbus >= s*th.modbus;
Rr(:,:,4) = D.http   >= s*th.http;
flag = any(Rr, 3);
rule = zeros(size(flag));
for q = 4:-1:1                   % lowest rule ID has priority
    rule(Rr(:,:,q)) = q;
end
halfopen = 1 - D.agg_comp ./ max(D.agg_syn, eps);
aggflag  = D.agg_syn >= s*th.syn_agg & halfopen >= th.agg_halfopen;
end

function [TP, nP, FP, nN] = windowCounts(flag, aggflag, D, P, ATK)
% Positives: 1 s windows inside the attack (attacker flagged or R5 fired).
% Negatives: every window of every benign host, plus R5 outside the attack
% (one-window guard after the attack ends for feature decay).
nW = ceil(P.T_sim/P.W_eval);
w  = min(nW, floor(D.tp/P.W_eval) + 1);
nS = size(flag, 1);
srcW = false(nS, nW);
for s = 1:nS
    srcW(s,:) = accumarray(w(:), double(flag(s,:))', [nW 1], @max)' > 0;
end
aggW   = accumarray(w(:), double(aggflag(:)), [nW 1], @max)' > 0;
wStart = (0:nW-1)*P.W_eval;
wEnd   = wStart + P.W_eval;
posW   = wStart >= P.attack_start & wEnd <= P.attack_end;
negW   = wEnd <= P.attack_start | wStart >= P.attack_end + P.W;
benign = setdiff(1:nS, ATK);
TP = sum(srcW(ATK,posW) | aggW(posW));
nP = nnz(posW);
FP = sum(sum(srcW(benign,:))) + sum(aggW(negW));
nN = numel(benign)*nW + nnz(negW);
end

function Q = simQueue(arrivals, P)
% Fluid drop-tail queue at the PLC communication module.
N = numel(arrivals);
S = P.mu_plc*P.dt;
q = zeros(1, N);
p = zeros(1, N);
for k = 1:N-1
    A  = arrivals(k);
    qn = q(k) + A - S;
    of = max(0, qn - P.B_max);
    if A > 0
        p(k) = of / A;
    end
    q(k+1) = min(P.B_max, max(0, qn));
end
Q.q = q;
Q.p = min(1, max(0, p));
Q.delay_ms = q / P.mu_plc * 1000;
end

function H = hmiMetrics(Q, poll, mask, P)
% Metrics for legitimate HMI polls inside 'mask'.
k   = find(poll & mask);
rtt = P.tau_prop_ms + Q.delay_ms(k) + P.tau_proc_ms;
pl  = Q.p(k);
H.loss     = mean(pl);
H.deliv    = 1 - H.loss;
H.rtt_mean = sum(rtt.*(1 - pl)) / max(sum(1 - pl), eps);
H.rtt_p99  = pctl(rtt, 99);
H.miss     = mean(pl + (1 - pl).*(rtt > P.deadline_ms));
H.goodput  = sum(1 - pl) / (nnz(mask)*P.dt);
end

function C = controllerLoad(pktin, P, extraCPU, nRules)
% CPU from packet-in rate; flow-table occupancy from reactive installs.
M  = round(1/P.dt);
Mi = round(P.flow_idle_timeout/P.dt);
pin_rate = movsum(pktin, [M-1 0]);
C.cpu  = min(100, P.ctrl_base_cpu + ...
    (100 - P.ctrl_base_cpu)*pin_rate/P.ctrl_max_pktin + extraCPU);
entries = movsum(pktin, [Mi-1 0]) + P.flow_static + nRules;
C.ft   = min(1, entries / P.flow_table_size);
C.full = entries >= P.flow_table_size;
end

function d = flowmodDelay(P)
% Controller decision + control channel + TCAM install, seconds.
d = (lognrnd_base(P.fm_ctrl_ms, P.fm_cv, [1 1]) + ...
     lognrnd_base(P.fm_chan_ms, P.fm_cv, [1 1]) + ...
     lognrnd_base(P.fm_tcam_ms, P.fm_cv, [1 1])) / 1000;
end

function x = lognrnd_base(m, cv, sz)
% Lognormal with mean m and coefficient of variation cv (base MATLAB).
sg = sqrt(log(1 + cv^2));
mu = log(m) - sg^2/2;
x  = exp(mu + sg*randn(sz));
end

function k = poissrnd_base(lambda)
% Poisson random numbers without the Statistics Toolbox.
% Knuth's method for lambda < 30, normal approximation above.
k   = zeros(size(lambda));
lam = lambda(:);
out = zeros(size(lam));
sm  = lam > 0 & lam < 30;
bg  = lam >= 30;
if any(sm)
    ls  = lam(sm);
    L   = exp(-ls);
    p   = rand(size(ls));
    n   = zeros(size(ls));
    act = p > L;
    while any(act)
        n(act) = n(act) + 1;
        p(act) = p(act) .* rand(nnz(act), 1);
        act    = p > L;
    end
    out(sm) = n;
end
if any(bg)
    lb = lam(bg);
    out(bg) = max(0, round(lb + sqrt(lb).*randn(size(lb))));
end
k(:) = out;
end

function S = summarize(X)
% Mean, SD and 95% CI half-width over runs (dimension 1), ignoring NaN.
n      = sum(~isnan(X), 1);
S.mean = mean(X, 1, 'omitnan');
S.sd   = std(X, 0, 1, 'omitnan');
tc     = arrayfun(@tcrit975, max(n - 1, 1));
S.ci   = tc .* S.sd ./ sqrt(max(n, 1));
S.n    = n;
end

function tc = tcrit975(df)
% Two-sided 95% Student-t critical value (Cornish-Fisher expansion).
z  = 1.959963984540054;
tc = z + (z^3 + z)/(4*df) + (5*z^5 + 16*z^3 + 3*z)/(96*df^2) + ...
     (3*z^7 + 19*z^5 + 17*z^3 - 15*z)/(384*df^3);
end

function q = pctl(x, p)
% Percentile with linear interpolation (no Statistics Toolbox).
x = sort(x(:));
n = numel(x);
if n == 0, q = NaN; return; end
pos = 1 + (n - 1)*p/100;
lo  = floor(pos);
hi  = ceil(pos);
q   = x(lo) + (pos - lo)*(x(hi) - x(lo));
end

function [mu, ci] = modePair(Sx)
% Reshape summaries to nAtk x nMode.
mu = reshape(Sx.mean, [], size(Sx.mean,3));
ci = reshape(Sx.ci,   [], size(Sx.ci,3));
end

function b = groupedBars(mu, ci, varargin)
b = bar(mu);
hold on;

% Apply colours when supplied; otherwise use MATLAB defaults
for j = 1:min(numel(varargin), numel(b))
    b(j).FaceColor = varargin{j};
end

% Add confidence intervals for every mode
for j = 1:size(mu,2)
    errorbar(b(j).XEndPoints, mu(:,j), ci(:,j), 'k', 'LineStyle', 'none', 'HandleVisibility', 'off');
end
end


function addBarLabels(b, ytop, fmt, fs)
% Display value labels above every grouped bar.
for j = 1:numel(b)
    x = b(j).XEndPoints;
    v = b(j).YData;

    for i = 1:numel(x)
        text(x(i), ytop(i,j), sprintf(fmt, v(i)), ...
            'HorizontalAlignment', 'center', ...
            'VerticalAlignment', 'bottom', ...
            'FontWeight', 'bold', ...
            'FontSize', fs, ...
            'Clipping', 'off');
    end
end
end


function setCategoryAxis(names)
set(gca, 'XTick', 1:numel(names), 'XTickLabel', names);
xtickangle(20);
end

function s = num2strIfNum(v)
if isnumeric(v), s = num2str(v); else, s = v; end
end
