SDN-BASED ICS CYBERSECURITY FRAMEWORK SIMULATION
APPENDIX B - REPRODUCIBILITY PACKAGE

1. SOFTWARE REQUIREMENTS
MATLAB R2024b was used for the reported simulation results.
The source code requires MATLAB R2020a or later.
Base MATLAB functions are used; no additional toolboxes are required.

2. SIMULATION CONFIGURATION
Simulation duration: 120 seconds.
Time step: 0.01 seconds.
Monte Carlo runs: 30.
Base random seed: 2026.
Attack window: 45 to 90 seconds.
Bottleneck capacity: 1000 packets per second.
Buffer capacity: 200 packets.

3. ATTACK SCENARIOS
TCP Port Scan.
Modbus/TCP Flood.
TCP SYN Flood (spoofed).
HTTP Flood.

4. RANDOM SEED SCHEME
The random-number generator uses the Twister algorithm.
For run r and attack scenario a, the seed is 2026 + 1000*r + a.
Runs are indexed from 1 to 30; scenarios are indexed from 1 to 4.

5. HOW TO RUN THE SIMULATION
Open the Appendix_B_Simulation_Artefacts folder in MATLAB.
Set the Appendix_B_Simulation_Artefacts folder as the MATLAB Current Folder.
Run the script using:
run(fullfile('01_Source_Code','sdn_Code_REPRODUCIBILITY.m'))
Generated figures and Excel tables will be written to the package's main folder.
The archived copies of the figures and tables are retained in their respective subfolders.

6. OUTPUTS
Nine PNG figures and four Excel summary tables are generated.
PerRun_MonteCarlo_Results.xlsx contains 120 run/scenario records.
PerRun_Raw_Simulation_Data.mat contains the raw simulation structures.

7. REPRODUCIBILITY NOTES
The model is a MATLAB-based simulation, not a live SDN controller or physical ICS testbed.
The mitigation mechanism models SDN/OpenFlow-inspired behaviour.
The reported results are based on the specified simulation configuration.
